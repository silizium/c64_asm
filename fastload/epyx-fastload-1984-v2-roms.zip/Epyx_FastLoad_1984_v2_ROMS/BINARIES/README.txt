https://www.pcbway.com/project/member/?bmbno=5B9D77D5-9033-46

BINARIES contains Epyx FastLoad 1984 v2 ROMS for 27c64 or 27c128 or 27c256 or 27c512 (DIP28)

Tip: Usually W27C512 is easy to find and cheaper.



