StarDOSfix.exe (C) Magnus Starseth 2017

Usage: StarDOSfix <input filename> <output filename>

This program fixes the switched D1-D2 bits in the ROM.
Run it again on the "decoded" file to make a file that
can be programmed into a PROM and used in the StarDOS
cartridge.

They switched places on the D1 and D2 data pins,
probably as some form of obfuscation of the code.
